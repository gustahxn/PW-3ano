import "./App.css";
import AppRoutes from "./approutes";

function App() {
  return (
    <>
      <AppRoutes />
    </>
  );
}

export default App;
