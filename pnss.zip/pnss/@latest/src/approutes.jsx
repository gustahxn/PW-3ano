import { BrowserRouter, Routes, Route, Link, Router } from "react-router-dom";
import Home from "./pages/Home";
import Sobre from "./pages/Sobre";

export default function AppRoutes() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Sobre" element={<Sobre />} />
      </Routes>
    </BrowserRouter>
  );
}
