import Header from "../components/Header";
export default function Home() {
  return (
    <>
      <Header />
      <h1>Página Inicial</h1>
    </>
  );
}
