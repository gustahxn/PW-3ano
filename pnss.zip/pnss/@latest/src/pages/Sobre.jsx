export default function Sobre() {
  return (
    <>
      <h1>Sobre nós</h1>
    </>
  );
}
