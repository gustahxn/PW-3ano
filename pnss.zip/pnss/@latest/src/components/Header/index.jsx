export default function header() {
  return (
    <header>
      <nav>
        <a href="#" style={{ margin: "10px" }}>
          Home
        </a>
        <a href="#" style={{ margin: "10px" }}>
          Sobre
        </a>
        <a href="#" style={{ margin: "10px" }}>
          Contato
        </a>
      </nav>
    </header>
  );
}
