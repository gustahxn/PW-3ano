export default function footer() {
  return (
    <footer>
      <nav>
        <a href="#">Nós</a>
        <br />
        <a href="#">Palmeiras</a>
        <br />
        <a href="#">AAAA</a>
      </nav>
    </footer>
  );
}
