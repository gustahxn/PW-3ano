export default function footer() {
  return (
    <footer>
      <nav>
        <a href="#" style={{ margin: "5px" }}>
          Nós
        </a>
        <a href="#" style={{ margin: "5px" }}>
          Palmeiras
        </a>
        <a href="#" style={{ margin: "5px" }}>
          AAAA
        </a>
      </nav>
    </footer>
  );
}
